# AMR Discovery

A free local research pipeline for predicting a withheld meropenem or imipenem result from non-carbapenem MIC measurements. Runs on a CPU and produces an offline HTML report, model comparisons, source tables, audit records and figures.

**Version 0.1 is an executable research foundation.** Real public-data runs are exploratory. NDM/OXA-48 subgroup discovery, clinical validation, cross-laboratory independence and patient independence have not been established. Synthetic results are labeled SOFTWARE_DEMONSTRATION throughout.

## Start on Windows

Install free Python 3.12, extract this folder, and open PowerShell here. The setup script installs only open-source packages in a local virtual environment.

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_windows.ps1
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m amr_discovery --help
```

To reproduce the included real-data pilot without downloading anything again:

```powershell
.\.venv\Scripts\python.exe -m amr_discovery run --data data/raw/ncbi_kp_human/observations.csv --config configs/public_pilot.json --out results/my_public_pilot
```

Open `results/my_public_pilot/report.html` in your browser. Use a new output folder for each run; prior results are never overwritten.

For Linux/macOS:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m amr_discovery run --data data/raw/ncbi_kp_human/observations.csv --config configs/public_pilot.json --out results/my_public_pilot
```

## What has been implemented

- Public BioSample antibiogram acquisition, caching, resumable downloads and hashes.
- Human-host and species eligibility, explicit feature allowlists and source provenance.
- Strict MIC parsing, censoring indicators, unresolved-bound handling, and missingness indicators.
- Separate reported-label and reviewed-breakpoint workflows; an illustrative rule file is blocked for real data.
- Curated positive/negative/unknown mechanisms, excluded from predictors.
- Connected patient/duplicate/isolate grouping; source, country, temporal and internal holdouts.
- Grouped inner model comparison: prevalence, species, missingness, logistic, random forest and histogram gradient boosting.
- Development-only calibration and operating thresholds, a saved model lock, and deferral analysis.
- Holdout metrics, group bootstrap intervals, subgroup tables and joint drug-column permutation analysis.
- Offline HTML reports, PNG/SVG curves and the exact CSV values behind figures.
- Integrity tests and a synthetic end-to-end fixture.

## Included executions

| Folder | Purpose |
|---|---|
| results/public_audit | Public-data eligibility audit |
| results/public_pilot | Internal exploratory holdout |
| results/public_source_holdout | Exploratory holdout of BioProject PRJNA278886 |
| results/demo | Synthetic software verification |

Open each `report.html` to see actual retained results. Do not use synthetic metrics as AMR evidence. A BioProject holdout is not proof of independent recruitment, patient independence or geographic generalization.

## Download a new public cohort for free

```powershell
.\.venv\Scripts\python.exe -m amr_discovery fetch-ncbi --query "Klebsiella pneumoniae[Organism] AND antibiogram[filter] AND (Homo sapiens[All Fields] OR human[All Fields])" --limit 2500 --out data/raw/new_ncbi_kp
```

For interrupted downloads, repeat the exact command with `--resume`. The original query and limit must match. Rate limiting and retries are included. NCBI results are public, submitter-supplied measured phenotypes; method quality and clinical representativeness need separate review.

Source documentation: https://www.ncbi.nlm.nih.gov/pathogens/docs/ast/ and https://www.ncbi.nlm.nih.gov/biosample/docs/antibiogram/

## Import your own licensed measurements

Use the column schema in `docs/DATA_DICTIONARY.md`. Files are CSV, one row per isolate-drug measurement. Keep original measurements and source references. The program does not substitute genomic predictions for phenotypic labels.

Run an audit before modeling:

```powershell
.\.venv\Scripts\python.exe -m amr_discovery audit --data data/your_observations.csv --config configs/public_pilot.json --out results/your_audit
```

Copy a configuration and declare your target, single interpretation standard, eligible species, drugs, panel minimum and holdout. Choose holdouts before looking at model performance. Core features exclude every carbapenem, all genotype fields and identifiers. Minimum class gates are software checks, not publication-ready sample-size criteria.

## Labels and breakpoints

The included real-data pilot uses reported CLSI R versus S and explicitly excludes I and unresolved labels. Standard versions are not supplied for many records. `allow_unversioned_reported` is an explicit exploratory option, not harmonization.

For harmonized labels, use `label_mode: "breakpoints"` and pass `--breakpoints path/to/reviewed_rules.json`. Replace the illustrative rules with microbiologist-reviewed species-specific values, a version and a citation. The engine represents S <= s_max and R >= r_min, with I between them. If the chosen standard uses different boundary operators, it needs an engine extension and tests before use. Never relabel illustrative numbers as clinical rules.

EUCAST I is susceptible at increased exposure. `R_vs_nonR` is supported only for EUCAST; non-R does not mean susceptible at standard dosing. MIC intervals spanning classes remain unresolved. Disk diffusion, combination-drug MIC ratios and colistin are not part of the default v0.1 modeling panel.

## Costs

This software uses no paid APIs, hosted models, subscriptions, database billing, GPUs or cloud instances. Computation and reports are local. NCBI acquisition requires no paid account. Dependencies are open source. Existing computer, internet and electricity are the remaining practical resources.

ATLAS access through Vivli may require approval and agreement to terms; it is not required to run this package. No account was created, request submitted or paid service enabled. Any future source with a fee is outside the current zero-service-cost workflow.

## Research boundaries and next work

See `docs/IMPLEMENTATION_STATUS.md` for the exact implemented/deferred scope. The immediate research dependency is independently curated mechanism evidence and a second compatible clinical collection. Model performance from these runs does not establish a groundbreaking discovery.

Run outputs retain configuration, input hash, split manifest, source counts, exclusions, predictions and model parameters. Models use joblib for trusted local serialization; only load model files you created or trust. Code is MIT licensed; upstream data retain their source terms.

## Live team lab (v0.2)

Open https://amr-research-lab.samads14122003.chatgpt.site for browser-local training, audits, test predictions and exploratory training-only networks. See [team instructions and verification](docs/TEAM_LAB.md). India-specific accuracy and clinical validation are not established. Download every run before closing the tab.
