Runtime verification (Node, no browser UI):

```sh
npm install --prefix test-runtime pyodide@0.29.3
node verify-runtime.mjs
```

This runs the shipped Python modules in the pinned WebAssembly runtime. End-to-end training, reports, ZIP exports, single-isolate prediction, unknown gene handling, India sample gates and the public source-held-out result were checked. Python tests: 34 passed. JavaScript syntax and local asset links passed. Browser visual and click-through QA were unavailable.
